
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class WithDrawCode
 */
@WebServlet("/WithDrawCode")
public class WithDrawCode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WithDrawCode() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try
		{
			String Account_Number=request.getParameter("acno");
			String Name=request.getParameter("uname");
			String Password=request.getParameter("pswd");
			double amt=Double.parseDouble(request.getParameter("amt"));
			
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","mndb","mndb");
				PreparedStatement ps2=con.prepareStatement("select acc_state from Account where Account_Number=? and Name=? and password=?");
				ps2.setString(1,Account_Number);
				ps2.setString(2, Name);
				ps2.setString(3, Password);
				ResultSet rs1=ps2.executeQuery();
			    String acstate=null;
				if(rs1.next())
				{
					acstate=rs1.getString(1);
					
				         out.print(acstate);
				
			         if(acstate.equals("active"))
			        {
				     PreparedStatement ps=con.prepareStatement("select amount from Account where Account_Number=? and Name=? and Password=?");
				     ps.setString(1,Account_Number);
				     ps.setString(2, Name);
				     ps.setString(3,Password);
				     ResultSet rs=ps.executeQuery();
				     Double balance=0.0;
				      if(rs.next())
				      {
					  balance=Double.parseDouble(rs.getString(1));
					  if(amt>balance)
					  {
						out.println("Sorry insufficient balance");
					  }
					  else
					   {
						double wd=balance-amt;
						PreparedStatement ps1=con.prepareStatement("update Account set Amount=? where Account_Number=? and Name=? and Password=? ");
						ps1.setDouble(1, wd);
						ps1.setString(2,Account_Number);
						ps1.setString(3, Name);
						ps1.setString(4,Password);
						int i=ps1.executeUpdate();	
						 if(i==1)
						 {
							out.println("Your balance has decrease "+amt);
						 }
					   
				        }
				      }
			        }
			     
				    else
				    {
				    	out.print("your account is deactivated");
				    	out.print("Please create new account");
				    }
					
				}
				else
				{
					out.println("Please Create the account");
				}
	}
		
				
		catch(Exception e)
		{
			out.println(e);
		}
		
	}

}
