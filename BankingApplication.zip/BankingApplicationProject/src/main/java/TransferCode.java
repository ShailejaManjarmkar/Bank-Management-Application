
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TransferCode
 */
@WebServlet("/TransferCode")
public class TransferCode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransferCode() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try
		{
			String Account_Number=request.getParameter("acno");
			String Name=request.getParameter("uname");
			String Password=request.getParameter("pswd");
			String TAN=request.getParameter("tac");
			Double amt=Double.parseDouble(request.getParameter("amt"));
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","mndb","mndb");
			
			
			PreparedStatement ps4=con.prepareStatement("select acc_state from Account where Account_Number=? and Name=? and password=?");
			ps4.setString(1,Account_Number);
			ps4.setString(2, Name);
			ps4.setString(3, Password);
			ResultSet rs4=ps4.executeQuery();
		    String acstate=null;
			if(rs4.next())
			{
				acstate=rs4.getString(1);
				
			
			
		       if(acstate.equals("active"))
		     {
			      PreparedStatement ps=con.prepareStatement("select Amount from Account where Account_Number=? and Name=? and Password=?");
			      ps.setString(1, Account_Number);
			      ps.setString(2, Name);
			      ps.setString(3, Password);
			      ResultSet rs=ps.executeQuery();
			      double balance=0.0;
			       if(rs.next())
			      {
				        balance=Double.parseDouble(rs.getString(1));//102000
				         if(amt>balance)
				         {
					        out.println("Insufficent balance");
				          }
				          else
				         {
					       PreparedStatement ps1=con.prepareStatement("select Amount from Account where Account_Number=?");
					       ps1.setString(1,TAN);
					       ResultSet rs1=ps1.executeQuery();
					       double balance1=0.0;
					       if(rs1.next())
					      {
						     balance1=Double.parseDouble(rs1.getString(1));
						
						
					      }
					       double ta=balance-amt;//102000-2000=100000
					       double fb=balance1+amt;//2000+2000=40000
					 
					        PreparedStatement ps2=con.prepareStatement("update Account set Amount=? where Account_Number=?");
					        ps2.setDouble(1,fb );
					        ps2.setString(2, TAN);
					        int i=ps2.executeUpdate();
					        PreparedStatement ps3=con.prepareStatement("update Account set Amount=? where Account_Number=? and Name=? and Password=? ");
					          ps3.setDouble(1,ta );
					        ps3.setString(2,Account_Number);
					       ps3.setString(3,Name);
					        ps3.setString(4, Password);
					        int j=ps3.executeUpdate();
					     if(i==1&&j==1)
					     {
						   out.println("The target account balance is"+fb+"reduced balance is "+amt);
					     }
					
				      }
			     }
		     }
			  else
			   {
				out.print("your account is deactivated");
			   }
			      
		  
		   }	
				
	     
			else
			{
				out.println("Please create the account");
			}
		}
			
			
		catch(Exception e)
		{
			out.print(e);
		}
		
	}

}
