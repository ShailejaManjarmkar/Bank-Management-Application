import java.sql.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BalanceCode
 */
@WebServlet("/BalanceCode")
public class BalanceCode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BalanceCode() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try
		{
			String Account_Number=request.getParameter("acno");
			String Name=request.getParameter("uname");
			String Password=request.getParameter("pswd");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","mndb","mndb");
			PreparedStatement ps2=con.prepareStatement("select acc_state from Account where Account_Number=? and Name=? and password=?");
			ps2.setString(1,Account_Number);
			ps2.setString(2, Name);
			ps2.setString(3, Password);
			ResultSet rs1=ps2.executeQuery();
		    String acstate=null;
			if(rs1.next())
			{
				acstate=rs1.getString(1);
				if(acstate.equals("active"))
				{
			       PreparedStatement ps=con.prepareStatement("select *  from Account where Account_Number=? and Name=? and Password=?");
			
			        ps.setString(1,Account_Number );
			        ps.setString(2, Name);
			        ps.setString(3, Password);
			        ResultSet rs=ps.executeQuery();
			        ResultSetMetaData rss=rs.getMetaData();
			        out.print("<table border='1'>");
			          int n=rss.getColumnCount();
			          for(int i=1;i<=n;i++)
			         {
				     out.print(" <th> "+ rss.getColumnName(i)+"</th>");
			         }	
				      while(rs.next())
				      {
					 out.print("<tr>");
					  for(int j=1;j<=n;j++)
					  {
					    out.print("<td>"+rs.getString(j)+"</td>");
					 
					   }
					    out.print("</tr>");
				      }
				     out.print("</table>");
				}
				else
				{
					out.print("your account is deactivated"+"<br>");
					out.print("Please create new account");
				
				}
			}
			else
			{
				out.print("please create new account");
			}
			
		}
		catch(Exception e)
		{
			out.print(e);
		}
		
	}

}
