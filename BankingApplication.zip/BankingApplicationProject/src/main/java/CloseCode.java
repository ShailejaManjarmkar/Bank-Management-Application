

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CloseCode
 */
@WebServlet("/CloseCode")
public class CloseCode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CloseCode() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		try
		{
			String Account_Number=request.getParameter("acno");
			String Name=request.getParameter("uname");
			String Password=request.getParameter("pswd");
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","mndb","mndb");
			PreparedStatement ps=con.prepareStatement("update Account set acc_state=? where Account_Number=? and Name=? and Password=?" );
			ps.setString(1,"deactive");
			ps.setString(2, Account_Number);
			ps.setString(3, Name);
			ps.setString(4, Password);
			int i=ps.executeUpdate();
			if(i==1)
			{
				out.print(" Welcome "+Name+" your account no "+ Account_Number +" has closed ");
			}
		}
		catch(Exception e)
		{
			out.print(e);
		}
		
	}

}
