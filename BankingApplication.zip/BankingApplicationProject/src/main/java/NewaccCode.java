

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewaccCode
 */
@WebServlet("/NewaccCode")
public class NewaccCode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewaccCode() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try
		{
			String Account_Number=request.getParameter("acno");
			String Name=request.getParameter("uname");
			String Password=request.getParameter("pswd");
			String Confirm_password=request.getParameter("cpswd");
			Double Amount=Double.parseDouble(request.getParameter("amt"));
			String Address=request.getParameter("address");
			String Mobile_No=request.getParameter("mno");
			String a="active";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","mndb","mndb");
			PreparedStatement ps=con.prepareStatement("insert into Account values(?,?,?,?,?,?,?,?)");
			ps.setString(1,Account_Number );
			ps.setString(2,Name);
			ps.setString(3, Password);
			ps.setString(4,Confirm_password );
			ps.setDouble(5,Amount);
			ps.setString(6, Address);
			ps.setString(7, Mobile_No);
			ps.setString(8, a);
			
			int i=ps.executeUpdate();
			out.print(i+"inserted succesfully");
			
		}
		catch(Exception e)
		{
			out.print(e);
		}
		
	}

}
