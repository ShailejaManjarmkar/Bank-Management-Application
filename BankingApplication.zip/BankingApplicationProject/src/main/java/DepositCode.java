
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
/**
 * Servlet implementation class DepositCode
 */
@WebServlet("/DepositCode")
public class DepositCode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DepositCode() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try
		{
			String Account_Number=request.getParameter("acno");
			String Name=request.getParameter("uname");
			String Password=request.getParameter("pswd");
			double amt=Double.parseDouble(request.getParameter("amt"));
			
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","mndb","mndb");
				PreparedStatement ps2=con.prepareStatement("select acc_state from Account where Account_Number=? and Name=? and password=?");
				ps2.setString(1,Account_Number);
				ps2.setString(2, Name);
				ps2.setString(3, Password);
				ResultSet rs1=ps2.executeQuery();
			    String acstate=null;
				if(rs1.next())
				{
					acstate=rs1.getString(1);
					
				
				
			       if(acstate.equals("active"))
			     {
				    PreparedStatement ps=con.prepareStatement("select amount from Account where Account_Number=? and Name=? and password=?");
				    ps.setString(1,Account_Number);
				    ps.setString(2, Name);
				    ps.setString(3, Password);
				    ResultSet rs=ps.executeQuery();
			       Double amount=0.0;
				   if(rs.next())
				   {
					amount=Double.parseDouble(rs.getString(1));
				   }
					Double newamt=amount+amt;
					PreparedStatement ps1=con.prepareStatement("update Account set Amount=? where Account_Number=? and Name=? and password=?");
					ps1.setDouble(1, newamt);
				    ps1.setString(2, Account_Number);
				    ps1.setString(3,Name);
				    ps1.setString(4, Password);
				    int i=ps1.executeUpdate();
				    out.print("Your balance has increase"+amt);
				    con.close();
			     }
			       else
		          {
		    	   out.println("your account is deactivated ");
		    	   out.println("please create new account");
				    	  
			        }
				    
			}
			else
			{
				out.print("Please Create the Account");
			}
				
				
				
				
			}
			catch(Exception e)
			{
				out.print(e);
			}
			
			
	}

}
